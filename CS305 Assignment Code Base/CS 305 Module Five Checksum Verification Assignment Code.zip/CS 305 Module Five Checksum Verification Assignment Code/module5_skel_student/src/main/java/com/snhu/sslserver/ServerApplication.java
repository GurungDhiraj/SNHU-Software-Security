package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


@SpringBootApplication
public class ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}

}

@RestController
class ServerController{
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
    public String shaEncryption(String input) throws NoSuchAlgorithmException
    {
    	MessageDigest encrypt = MessageDigest.getInstance("SHA-256");
    	byte[] encryptedByte = encrypt.digest(input.getBytes());
    	
    	// Convert byte to bigInt
    	BigInteger bigInt = new BigInteger(1, encryptedByte);
    	
    	return bigInt.toString(16);
    	
    }
    
	@RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
		String data = "Hello Dhiraj Gurung!";
		String hash = shaEncryption(data);
        
        return "<p>data:" + data + " SHA-256: " + hash;
    }
}
